<!--
Add an optional short description here for `Mercedes-c2-2-nl` view.
Or delete this file if not applicable.
-->