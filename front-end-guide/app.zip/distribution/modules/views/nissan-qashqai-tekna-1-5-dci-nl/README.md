<!--
Add an optional short description here for `Nissan-qashqai-tekna-1-5-dci-nl` view.
Or delete this file if not applicable.
-->