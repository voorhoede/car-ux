<!--
Add an optional short description here for `text-image` component.
Or delete this file if not applicable.
-->