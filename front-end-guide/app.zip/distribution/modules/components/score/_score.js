(function() {
	'use strict';

	new window.Expandible();
})();