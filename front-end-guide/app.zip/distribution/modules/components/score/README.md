<!--
Add an optional short description here for `score` component.
Or delete this file if not applicable.
-->