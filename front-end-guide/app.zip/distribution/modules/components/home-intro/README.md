<!--
Add an optional short description here for `home-intro` component.
Or delete this file if not applicable.
-->