<!--
Add an optional short description here for `bulletpoints` component.
Or delete this file if not applicable.
-->