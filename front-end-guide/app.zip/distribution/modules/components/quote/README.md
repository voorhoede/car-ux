<!--
Add an optional short description here for `quote` component.
Or delete this file if not applicable.
-->