<!--
Add an optional short description here for `header` component.
Or delete this file if not applicable.
-->