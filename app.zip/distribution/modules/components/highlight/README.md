<!--
Add an optional short description here for `highlight` component.
Or delete this file if not applicable.
-->