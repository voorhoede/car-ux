<!--
Add an optional short description here for `featured` component.
Or delete this file if not applicable.
-->