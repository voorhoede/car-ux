<!--
Add an optional short description here for `footer` component.
Or delete this file if not applicable.
-->