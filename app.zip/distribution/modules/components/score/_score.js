(function(d) {
	'use strict';

	//var scoreFirst = d.querySelector('[data-score-first]');

	new window.Expandible();

})(document);