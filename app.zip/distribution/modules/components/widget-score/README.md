<!--
Add an optional short description here for `widget-score` component.
Or delete this file if not applicable.
-->